#include "helper/helper.h"

int main() {
    char* roblox_title = obfuscate_const("Roblox");
    DWORD pid = GetProcIdStealth(roblox_title);
    delete[] roblox_title;

    HANDLE process = OpenProcess(PROCESS_ALL_ACCESS, FALSE, pid);
    if (!process) return EXIT_FAILURE;

    char* dll_path = obfuscate_const("Exploit.dll"); // ur ugly dll name 
    HANDLE file = CreateFileA(dll_path, GENERIC_READ, 0, nullptr, OPEN_EXISTING, 0, nullptr);
    delete[] dll_path;
    if (file == INVALID_HANDLE_VALUE) return EXIT_FAILURE;

    DWORD size = GetFileSize(file, nullptr);
    std::vector<BYTE> dll_data(size);
    ReadFile(file, dll_data.data(), size, nullptr, nullptr);
    CloseHandle(file);

    IMAGE_DOS_HEADER* dos_header = reinterpret_cast<IMAGE_DOS_HEADER*>(dll_data.data());
    IMAGE_NT_HEADERS* nt_headers = reinterpret_cast<IMAGE_NT_HEADERS*>(dll_data.data() + dos_header->e_lfanew);

    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_int_distribution<> dis(0, 255);
    HANDLE section = nullptr;
    LARGE_INTEGER section_size = { nt_headers->OptionalHeader.SizeOfImage + (dis(gen) % 0x1000) };
    NtCreateSection(§ion, SECTION_ALL_ACCESS, nullptr, §ion_size, PAGE_EXECUTE_READWRITE, SEC_COMMIT | (dis(gen) % 2 ? SEC_RESERVE : 0), nullptr);
    if (!section) return EXIT_FAILURE;

    PVOID local_base = nullptr;
    SIZE_T view_size = 0;
    NtMapViewOfSection(section, GetCurrentProcess(), &local_base, dis(gen) % 0x1000, 0, nullptr, &view_size, 1, 0, PAGE_READWRITE);
    if (!local_base) return EXIT_FAILURE;

    PVOID remote_base = nullptr;
    NtMapViewOfSection(section, process, &remote_base, dis(gen) % 0x1000, 0, nullptr, &view_size, 1, 0, PAGE_EXECUTE_READWRITE);
    if (!remote_base) return EXIT_FAILURE;

    memcpy(local_base, dll_data.data(), nt_headers->OptionalHeader.SizeOfHeaders);
    IMAGE_SECTION_HEADER* section_header = IMAGE_FIRST_SECTION(nt_headers);
    for (WORD i = 0; i < nt_headers->FileHeader.NumberOfSections; i++) {
        memcpy(reinterpret_cast<BYTE*>(local_base) + section_header[i].VirtualAddress, 
               dll_data.data() + section_header[i].PointerToRawData, section_header[i].SizeOfRawData);
    }

    LPVOID entry_point = reinterpret_cast<LPVOID>(reinterpret_cast<uintptr_t>(remote_base) + nt_headers->OptionalHeader.AddressOfEntryPoint);
    std::vector<BYTE> shellcode = GenerateShellcode(remote_base, entry_point);

    PVOID shellcode_base = nullptr;
    LARGE_INTEGER shellcode_size = { shellcode.size() + (dis(gen) % 0x500) };
    HANDLE shell_section = nullptr;
    NtCreateSection(&shell_section, SECTION_ALL_ACCESS, nullptr, &shellcode_size, PAGE_EXECUTE_READWRITE, SEC_COMMIT, nullptr);
    if (!shell_section) return EXIT_FAILURE;

    NtMapViewOfSection(shell_section, process, &shellcode_base, 0, 0, nullptr, &view_size, 1, 0, PAGE_EXECUTE_READWRITE);
    if (!shellcode_base) return EXIT_FAILURE;

    memcpy(shellcode_base, shellcode.data(), shellcode.size());

    HANDLE snapshot = CreateToolhelp32Snapshot(TH32CS_SNAPTHREAD, 0);
    THREADENTRY32 te = { sizeof(te) };
    DWORD tid = 0;
    if (Thread32First(snapshot, &te)) {
        do {
            if (te.th32OwnerProcessID == pid) {
                tid = te.th32ThreadID;
                break;
            }
        } while (Thread32Next(snapshot, &te));
    }
    CloseHandle(snapshot);

    if (!tid) return EXIT_FAILURE;

    HANDLE thread = OpenThread(THREAD_ALL_ACCESS, FALSE, tid);
    if (!thread) return EXIT_FAILURE;

    CONTEXT ctx = { CONTEXT_FULL };
    ctx.ContextFlags = CONTEXT_FULL;
    GetThreadContext(thread, &ctx);
    ctx.Rip = reinterpret_cast<uint64_t>(GetProcAddress(GetModuleHandleA(obfuscate_const("kernel32.dll")), obfuscate_const("Sleep")));
    SetThreadContext(thread, &ctx);

    NtQueueApcThread(thread, reinterpret_cast<PVOID>(shellcode_base), nullptr, nullptr, 0);
    ResumeThread(thread);

    std::cin.get();

    NtUnmapViewOfSection(process, shellcode_base);
    NtUnmapViewOfSection(process, remote_base);
    NtUnmapViewOfSection(GetCurrentProcess(), local_base);
    CloseHandle(shell_section);
    CloseHandle(section);
    CloseHandle(thread);
    CloseHandle(process);

    return EXIT_SUCCESS;
}
