#pragma once

#include <windows.h>
#include <vector>
#include <thread>
#include <random>
#include <cstring>


// yes i love XOR
constexpr char XOR_KEY = 0xA5;

inline void xor_string(char* str, size_t len) {
    for (size_t i = 0; i < len; i++) str[i] ^= XOR_KEY;
}

inline char* obfuscate_const(const char* str) {
    size_t len = strlen(str) + 1;
    char* obf = new char[len];
    strcpy_s(obf, len, str);
    xor_string(obf, len - 1);
    return obf;
}

FARPROC get_proc_address_obf(HMODULE module, const char* proc_name) {
    char* obf_name = obfuscate_const(proc_name);
    FARPROC addr = GetProcAddress(module, obf_name);
    delete[] obf_name;
    return addr;
}

DWORD GetProcIdStealth(const char* title) {
    char* obf_title = obfuscate_const(title);
    HWND hwnd = nullptr;
    while (!(hwnd = FindWindowA(nullptr, obf_title))) {
        std::this_thread::sleep_for(std::chrono::milliseconds(250));
    }
    delete[] obf_title;
    DWORD pid = 0;
    GetWindowThreadProcessId(hwnd, &pid);
    return pid;
}

std::vector<BYTE> EncryptShellcode(std::vector<BYTE>& shellcode) {
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_int_distribution<> dis(0, 255);
    BYTE key = static_cast<BYTE>(dis(gen));
    std::vector<BYTE> encrypted = { key };
    for (BYTE b : shellcode) encrypted.push_back(b ^ key);
    for (int i = 0; i < 10; i++) encrypted.insert(encrypted.begin() + dis(gen) % encrypted.size(), static_cast<BYTE>(dis(gen)));
    return encrypted;
}

std::vector<BYTE> GenerateShellcode(LPVOID dll_base, LPVOID entry_point) {
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_int_distribution<> dis(0, 255);

    std::vector<BYTE> shellcode = {
        0x48, 0x31, 0xC9,
        0xB1, 0x00,
        0x48, 0x8D, 0x05, 0x07, 0x00, 0x00, 0x00,
        0x8A, 0x10,
        0x48, 0xFF, 0xC0,
        0x30, 0x10,
        0x48, 0xFF, 0xC1,
        0x80, 0xF9, 0x00,
        0x75, 0xF2,
        0x48, 0xB8, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0xFF, 0xD0,
        0xC3
    };

    for (int i = 0; i < 8; i++) {
        shellcode.insert(shellcode.begin() + dis(gen) % (shellcode.size() - 5), dis(gen) % 3 ? 0x90 : (dis(gen) % 2 ? 0xCC : 0xF4));
    }

    shellcode[4] = static_cast<BYTE>(shellcode.size() - 22);
    *reinterpret_cast<uint64_t*>(&shellcode[22]) = reinterpret_cast<uint64_t>(entry_point);

    return EncryptShellcode(shellcode);
}

using NtCreateSection_t = NTSTATUS(WINAPI*)(PHANDLE, ACCESS_MASK, POBJECT_ATTRIBUTES, PLARGE_INTEGER, ULONG, ULONG, HANDLE);
using NtMapViewOfSection_t = NTSTATUS(WINAPI*)(HANDLE, HANDLE, PVOID*, ULONG_PTR, SIZE_T, PLARGE_INTEGER, PSIZE_T, DWORD, ULONG, ULONG);
using NtQueueApcThread_t = NTSTATUS(WINAPI*)(HANDLE, PVOID, PVOID, PVOID, ULONG);

NtCreateSection_t NtCreateSection = reinterpret_cast<NtCreateSection_t>(get_proc_address_obf(GetModuleHandleA(obfuscate_const("ntdll.dll")), "NtCreateSection"));
NtMapViewOfSection_t NtMapViewOfSection = reinterpret_cast<NtMapViewOfSection_t>(get_proc_address_obf(GetModuleHandleA(obfuscate_const("ntdll.dll")), "NtMapViewOfSection"));
NtQueueApcThread_t NtQueueApcThread = reinterpret_cast<NtQueueApcThread_t>(get_proc_address_obf(GetModuleHandleA(obfuscate_const("ntdll.dll")), "NtQueueApcThread"));
